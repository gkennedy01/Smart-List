package com.example.smartlist;

public class Lista {
    private int id;
    private String nome;

    public Lista(int id, String nome) {
        this.id = id;
        this.nome = nome;
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
}
