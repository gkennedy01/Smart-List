package com.example.smartlist;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.app.AlertDialog;
import android.widget.Toast;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ListaActivity extends AppCompatActivity {

    private static final String TAG = "ListaActivity";

    RecyclerView recyclerItens;
    Button btnAddItem;
    Button btnEditarLista;
    TextView tvNomeLista;
    DBHelper dbHelper;
    ArrayList<Item> itens;
    int listaId;

    AdapterItem adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.listaRoot), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerItens = findViewById(R.id.recyclerItens);
        btnAddItem = findViewById(R.id.btnAddItem);
        btnEditarLista = findViewById(R.id.btnEditarLista); // garante o findViewById
        tvNomeLista = findViewById(R.id.tvNomeListaSelecionada);
        dbHelper = new DBHelper(this);

        // Debug: checar se os views foram encontrados
        if (btnEditarLista == null) {
            Toast.makeText(this, "Erro: btnEditarLista não encontrado no layout (verifique o id)", Toast.LENGTH_LONG).show();
            Log.e(TAG, "btnEditarLista == null -> verifique activity_lista.xml (id @+id/btnEditarLista)");
        }
        if (btnAddItem == null) {
            Toast.makeText(this, "Erro: btnAddItem não encontrado no layout (verifique o id)", Toast.LENGTH_LONG).show();
            Log.e(TAG, "btnAddItem == null -> verifique activity_lista.xml (id @+id/btnAddItem)");
        }
        if (tvNomeLista == null) {
            Log.e(TAG, "tvNomeLista == null -> verifique activity_lista.xml (id @+id/tvNomeListaSelecionada)");
        }

        // Recebe id e nome da lista (inicial)
        Intent intent = getIntent();
        listaId = intent.getIntExtra("lista_id", -1);
        String listaNome = intent.getStringExtra("lista_nome");
        if (listaNome != null) {
            tvNomeLista.setText(listaNome);
        }

        // habilitar botão voltar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            if (listaNome != null) getSupportActionBar().setTitle(listaNome);
        }

        recyclerItens.setLayoutManager(new LinearLayoutManager(this));
        itens = new ArrayList<>();

        // Adapter (assumo que seu AdapterItem já está funcionando)
        adapter = new AdapterItem(
                this,
                itens,
                (item, position) -> {
                    Intent editIntent = new Intent(ListaActivity.this, EditItemActivity.class);
                    editIntent.putExtra("item_id", item.getId());
                    editIntent.putExtra("lista_id", item.getListaId());
                    editIntent.putExtra("item_nome", item.getNome());
                    editIntent.putExtra("item_quantidade", item.getQuantidade());
                    startActivity(editIntent);
                },
                (item, position) -> {
                    new AlertDialog.Builder(ListaActivity.this)
                            .setTitle("Excluir item")
                            .setMessage("Deseja excluir o item \"" + item.getNome() + "\"?")
                            .setNegativeButton("Cancelar", (d, i) -> d.dismiss())
                            .setPositiveButton("Excluir", (d, i) -> {
                                int rows = dbHelper.deleteItem(item.getId());
                                if (rows > 0) {
                                    itens.remove(position);
                                    adapter.notifyItemRemoved(position);
                                    Toast.makeText(ListaActivity.this, "Item excluído", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(ListaActivity.this, "Erro ao excluir item", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .show();
                }
        );

        recyclerItens.setAdapter(adapter);

        //-------------------------------------------------------
        //  BOTÃO ADD ITEM
        //-------------------------------------------------------
        if (btnAddItem != null) {
            btnAddItem.setOnClickListener(v -> {
                Intent addItemIntent = new Intent(ListaActivity.this, AddItemActivity.class);
                addItemIntent.putExtra("lista_id", listaId);
                startActivity(addItemIntent);
            });
        }

        //-------------------------------------------------------
        //  BOTÃO EDITAR LISTA -> abre EditListaActivity
        //-------------------------------------------------------
        if (btnEditarLista != null) {
            btnEditarLista.setOnClickListener(v -> {
                try {
                    Intent editListaIntent = new Intent(ListaActivity.this, EditListaActivity.class);
                    editListaIntent.putExtra("lista_id", listaId);
                    editListaIntent.putExtra("lista_nome", tvNomeLista != null ? tvNomeLista.getText().toString() : "");
                    startActivity(editListaIntent);
                } catch (Exception e) {
                    // Captura qualquer problema ao criar/iniciar a intent
                    Log.e(TAG, "Erro ao abrir EditListaActivity", e);
                    Toast.makeText(ListaActivity.this, "Falha ao abrir edição da lista: " + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        }

        // carrega itens e nome (caso o nome não tenha vindo no intent)
        refreshListaNome();
        carregarItens();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Recarrega nome (caso tenha sido editado) e items
        refreshListaNome();
        carregarItens();
    }

    private void carregarItens() {
        itens.clear();
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT id, lista_id, nome, quantidade FROM itens WHERE lista_id = ?",
                new String[]{String.valueOf(listaId)}
        );

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            int lista_id = cursor.getInt(cursor.getColumnIndexOrThrow("lista_id"));
            String nome = cursor.getString(cursor.getColumnIndexOrThrow("nome"));
            String quantidade = cursor.getString(cursor.getColumnIndexOrThrow("quantidade"));

            itens.add(new Item(id, lista_id, nome, quantidade));
        }

        cursor.close();
        adapter.notifyDataSetChanged();
    }

    private void refreshListaNome() {
        if (listaId == -1) return;

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT nome FROM listas WHERE id = ?", new String[]{String.valueOf(listaId)});
        if (cursor.moveToFirst()) {
            String nome = cursor.getString(cursor.getColumnIndexOrThrow("nome"));
            if (tvNomeLista != null) tvNomeLista.setText(nome);
            if (getSupportActionBar() != null) getSupportActionBar().setTitle(nome);
        }
        cursor.close();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
