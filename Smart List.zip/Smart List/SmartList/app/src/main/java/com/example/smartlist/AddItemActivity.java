package com.example.smartlist;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddItemActivity extends AppCompatActivity {

    private static final String TAG = "AddItemActivity";

    EditText etNomeItem, etQuantidade;
    Button btnSalvarItem;
    DBHelper dbHelper;
    int listaId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Ajuste para evitar que a câmera/notch cubra os elementos (root precisa ter id addItemRoot)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.addItemRoot), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etNomeItem = findViewById(R.id.etNomeItem);
        etQuantidade = findViewById(R.id.etQuantidade);
        btnSalvarItem = findViewById(R.id.btnSalvarItem);

        dbHelper = new DBHelper(this);

        // pega lista_id que foi enviada pela ListaActivity
        listaId = getIntent().getIntExtra("lista_id", -1);
        Log.d(TAG, "onCreate: recebido lista_id = " + listaId);

        btnSalvarItem.setOnClickListener(v -> {
            String nome = etNomeItem.getText().toString().trim();
            String quantidade = etQuantidade.getText().toString().trim();

            if (nome.isEmpty()) {
                Toast.makeText(this, "Digite o nome do item", Toast.LENGTH_SHORT).show();
                return;
            }

            if (listaId == -1) {
                Toast.makeText(this, "ID da lista inválido. Não foi possível adicionar.", Toast.LENGTH_SHORT).show();
                Log.e(TAG, "listaId inválido (-1). Intent não enviou lista_id corretamente.");
                return;
            }

            if (quantidade == null || quantidade.isEmpty() || quantidade.equals("0")) {
                quantidade = "1";
            }

            SQLiteDatabase db = dbHelper.getWritableDatabase();
            ContentValues values = new ContentValues();
            values.put("lista_id", listaId); // <<-- importante: salva a referência à lista
            values.put("nome", nome);
            values.put("quantidade", quantidade);

            long result = db.insert("itens", null, values);
            Log.d(TAG, "insert result = " + result + " for lista_id=" + listaId);

            // DEBUG opcional: quantos itens há agora nessa lista
            Cursor c = db.rawQuery("SELECT COUNT(*) FROM itens WHERE lista_id = ?", new String[]{String.valueOf(listaId)});
            if (c != null) {
                if (c.moveToFirst()) {
                    int count = c.getInt(0);
                    Log.d(TAG, "itens na lista " + listaId + " = " + count);
                    Toast.makeText(this, "Itens na lista agora: " + count, Toast.LENGTH_SHORT).show();
                }
                c.close();
            }

            if (result != -1) {
                Toast.makeText(this, "Item adicionado!", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK); // opcional
                finish();
            } else {
                Toast.makeText(this, "Erro ao adicionar item", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
