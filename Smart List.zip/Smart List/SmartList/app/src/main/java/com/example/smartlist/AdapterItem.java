package com.example.smartlist;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdapterItem extends RecyclerView.Adapter<AdapterItem.ViewHolder> {

    public interface OnItemLongClickListener {
        void onItemLongClick(Item item, int position);
    }

    public interface OnItemClickListener {
        void onItemClick(Item item, int position);
    }

    private Context context;
    private List<Item> itens;
    private OnItemLongClickListener longClickListener;
    private OnItemClickListener clickListener;

    public AdapterItem(Context context, List<Item> itens,
                       OnItemClickListener clickListener,
                       OnItemLongClickListener longClickListener) {
        this.context = context;
        this.itens = itens;
        this.clickListener = clickListener;
        this.longClickListener = longClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Item item = itens.get(position);
        holder.nomeItem.setText(item.getNome());
        holder.quantidadeItem.setText(item.getQuantidade() != null ? item.getQuantidade() : "");

        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) {
                clickListener.onItemClick(item, holder.getAdapterPosition());
            }
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                longClickListener.onItemLongClick(item, holder.getAdapterPosition());
                return true;
            }
            return false;
        });
    }

    @Override
    public int getItemCount() {
        return itens.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nomeItem, quantidadeItem;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nomeItem = itemView.findViewById(R.id.tvNomeItem);
            quantidadeItem = itemView.findViewById(R.id.tvQuantidadeItem);
        }
    }
}
