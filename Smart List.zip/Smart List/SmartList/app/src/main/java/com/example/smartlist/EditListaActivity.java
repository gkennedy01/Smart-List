package com.example.smartlist;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class EditListaActivity extends AppCompatActivity {

    EditText etNomeLista;
    Button btnSalvarLista;
    DBHelper dbHelper;
    int listaId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_lista);

        etNomeLista = findViewById(R.id.etNomeLista);
        btnSalvarLista = findViewById(R.id.btnSalvarLista);

        dbHelper = new DBHelper(this);

        listaId = getIntent().getIntExtra("lista_id", -1);
        String nome = getIntent().getStringExtra("lista_nome");
        etNomeLista.setText(nome);

        btnSalvarLista.setOnClickListener(v -> salvarLista());

    }

    private void salvarLista() {
        String nome = etNomeLista.getText().toString().trim();

        if (nome.isEmpty()) {
            Toast.makeText(this, "Digite o nome da lista!", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nome", nome);

        int result = db.update("listas", values, "id = ?", new String[]{String.valueOf(listaId)});

        if (result > 0) {
            Toast.makeText(this, "Lista atualizada!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Erro ao atualizar lista", Toast.LENGTH_SHORT).show();
        }
    }

    private void excluirLista() {
        if (listaId == -1) return;

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int result = db.delete("listas", "id = ?", new String[]{String.valueOf(listaId)});

        if (result > 0) {
            Toast.makeText(this, "Lista excluída!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Erro ao excluir lista", Toast.LENGTH_SHORT).show();
        }
    }
}
