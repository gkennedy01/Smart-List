package com.example.smartlist;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "smartlist.db";
    private static final int DATABASE_VERSION = 1;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createListas = "CREATE TABLE listas (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nome TEXT NOT NULL);";
        db.execSQL(createListas);

        String createItens = "CREATE TABLE itens (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "lista_id INTEGER, " +
                "nome TEXT NOT NULL, " +
                "quantidade INTEGER, " +
                "FOREIGN KEY(lista_id) REFERENCES listas(id) ON DELETE CASCADE);";
        db.execSQL(createItens);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS itens");
        db.execSQL("DROP TABLE IF EXISTS listas");
        onCreate(db);
    }

    // Deleta lista (itens vinculados serão deletados por cascade)
    public int deleteLista(int listaId) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("listas", "id = ?", new String[]{String.valueOf(listaId)});
    }

    // Deleta item por id
    public int deleteItem(int itemId) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("itens", "id = ?", new String[]{String.valueOf(itemId)});
    }

    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    public int updateItem(int itemId, String nome, String quantidade) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("nome", nome);
        cv.put("quantidade", quantidade);
        return db.update("itens", cv, "id = ?", new String[]{String.valueOf(itemId)});
    }


}
