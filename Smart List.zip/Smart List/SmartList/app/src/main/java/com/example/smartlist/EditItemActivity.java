package com.example.smartlist;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EditItemActivity extends AppCompatActivity {

    EditText etNomeItem, etQuantidade;
    Button btnSalvarItem, btnExcluirItem;
    DBHelper dbHelper;
    int itemId = -1;
    int listaId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_item);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.etNomeItem), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etNomeItem = findViewById(R.id.etNomeItem);
        etQuantidade = findViewById(R.id.etQuantidade);
        btnSalvarItem = findViewById(R.id.btnSalvarItem);
        btnExcluirItem = findViewById(R.id.btnExcluirItem);

        dbHelper = new DBHelper(this);

        // recebe dados da intent
        itemId = getIntent().getIntExtra("item_id", -1);
        listaId = getIntent().getIntExtra("lista_id", -1);
        String nome = getIntent().getStringExtra("item_nome");
        String quantidade = getIntent().getStringExtra("item_quantidade");

        if (nome != null) etNomeItem.setText(nome);
        if (quantidade != null) etQuantidade.setText(quantidade);

        btnSalvarItem.setOnClickListener(v -> salvarItem());
        btnExcluirItem.setOnClickListener(v -> excluirItem());
    }

    private void salvarItem() {
        String nome = etNomeItem.getText().toString().trim();
        String quantidade = etQuantidade.getText().toString().trim();

        if (nome.isEmpty()) {
            Toast.makeText(this, "Digite o nome do item", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("nome", nome);
        cv.put("quantidade", quantidade);
        // lista_id não deve mudar aqui, mas se quiser permitir, adicione

        int rows = db.update("itens", cv, "id = ?", new String[]{String.valueOf(itemId)});
        if (rows > 0) {
            Toast.makeText(this, "Item atualizado!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Erro ao atualizar item", Toast.LENGTH_SHORT).show();
        }
    }

    private void excluirItem() {
        if (itemId != -1) {
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            int rows = db.delete("itens", "id = ?", new String[]{String.valueOf(itemId)});
            if (rows > 0) {
                Toast.makeText(this, "Item excluído!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Erro ao excluir item", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
