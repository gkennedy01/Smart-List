package com.example.smartlist;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdapterLista extends RecyclerView.Adapter<AdapterLista.ViewHolder> {

    private Context context;
    private List<Lista> listas;
    private DBHelper dbHelper;

    public AdapterLista(Context context, List<Lista> listas) {
        this.context = context;
        this.listas = listas;
        this.dbHelper = new DBHelper(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_lista, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Lista lista = listas.get(position);
        holder.nomeLista.setText(lista.getNome());

        // ➤ ABRIR LISTA AO CLICAR
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, ListaActivity.class);
            intent.putExtra("lista_id", lista.getId());
            intent.putExtra("lista_nome", lista.getNome());
            context.startActivity(intent);
        });

        // ➤ DIALOG DE CONFIRMAÇÃO E EXCLUSÃO AO LONG CLICK (mesmo estilo do seu código)
        holder.itemView.setOnLongClickListener(v -> {
            // cria e mostra o AlertDialog
            new AlertDialog.Builder(context)
                    .setTitle("Excluir lista")
                    .setMessage("Deseja excluir a lista \"" + lista.getNome() + "\"?")
                    .setNegativeButton("Cancelar", (d, i) -> d.dismiss())
                    .setPositiveButton("Excluir", (d, i) -> {
                        // pega a posição atual do ViewHolder (evita inconsistência se a lista mudou)
                        int adapterPosition = holder.getAdapterPosition();
                        if (adapterPosition == RecyclerView.NO_POSITION) {
                            Toast.makeText(context, "Erro ao excluir lista", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        int rows = dbHelper.deleteLista(lista.getId()); // usa DBHelper

                        if (rows > 0) {
                            listas.remove(adapterPosition);
                            notifyItemRemoved(adapterPosition);
                            Toast.makeText(context, "Lista excluída", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, "Erro ao excluir lista", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .show();

            return true;
        });
    }

    @Override
    public int getItemCount() {
        return listas.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nomeLista;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nomeLista = itemView.findViewById(R.id.tvNomeListaItem);
        }
    }
}
