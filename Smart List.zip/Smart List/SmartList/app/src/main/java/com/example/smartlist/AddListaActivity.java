package com.example.smartlist;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;


import androidx.appcompat.app.AppCompatActivity;

public class AddListaActivity extends AppCompatActivity {

    EditText edtNomeLista;
    Button btnSalvarLista;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_lista);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.addListaRoot), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        edtNomeLista = findViewById(R.id.edtNomeLista);
        btnSalvarLista = findViewById(R.id.btnSalvarLista);
        dbHelper = new DBHelper(this);

        btnSalvarLista.setOnClickListener(v -> salvarLista());
    }

    private void salvarLista() {
        String nome = edtNomeLista.getText().toString().trim();

        if (nome.isEmpty()) {
            Toast.makeText(this, "Digite o nome da lista!", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("nome", nome);

        db.insert("listas", null, cv);

        Toast.makeText(this, "Lista criada!", Toast.LENGTH_SHORT).show();
        finish();
    }
}
