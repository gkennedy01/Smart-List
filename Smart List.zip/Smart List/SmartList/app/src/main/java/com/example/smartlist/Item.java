package com.example.smartlist;

public class Item {
    private int id;
    private int listaId;
    private String nome;
    private String quantidade;

    public Item(int id, int listaId, String nome, String quantidade) {
        this.id = id;
        this.listaId = listaId;
        this.nome = nome;
        this.quantidade = quantidade;
    }

    public int getId() { return id; }
    public int getListaId() { return listaId; }
    public String getNome() { return nome; }
    public String getQuantidade() { return quantidade; }
}
