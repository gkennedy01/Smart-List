package com.example.smartlist;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    DBHelper dbHelper;
    RecyclerView recyclerListas;
    ArrayList<Lista> listas;
    AdapterLista adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbHelper = new DBHelper(this);

        recyclerListas = findViewById(R.id.recyclerListas);
        recyclerListas.setLayoutManager(new LinearLayoutManager(this));

        listas = new ArrayList<>();
        adapter = new AdapterLista(this, listas);
        recyclerListas.setAdapter(adapter);

        Button btnAddLista = findViewById(R.id.btnAddLista);
        btnAddLista.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, AddListaActivity.class));
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        carregarListas();
    }

    private void carregarListas() {
        listas.clear();

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM listas", null);

        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
            String nome = cursor.getString(cursor.getColumnIndexOrThrow("nome"));

            listas.add(new Lista(id, nome));
        }

        cursor.close();
        adapter.notifyDataSetChanged();
    }
}

